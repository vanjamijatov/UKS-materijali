def function_b() -> str:
    return "Hi from function B!"
