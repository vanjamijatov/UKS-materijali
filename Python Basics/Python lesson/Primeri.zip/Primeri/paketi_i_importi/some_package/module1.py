def function_a() -> str:
    return "Hi from function A!"
