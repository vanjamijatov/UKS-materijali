
if __name__ == '__main__':
    print("Brojac")
    for i in range(10):
        print(i)

    print("Proizvoljan interval")
    for i in range(2,13):
        print(i)

    print("Proizvoljan inkrement")
    for i in range(3,10,2):
        print(i)

    print("Ispis u opadajucem redosledu")
    for i in range(10,-1,-1):
        print(i)
