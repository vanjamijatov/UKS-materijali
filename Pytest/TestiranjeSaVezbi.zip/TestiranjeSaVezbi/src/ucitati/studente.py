'''
Modul koji sadrzi funkcije za ucitavanje studenata iz fajla

@author: Zeljko Ivkovic
'''
from os.path import exists
from model.student import str2student

def ucitatiStudente(path):
    '''
    Metoda koja ucitava sve studente iz fajla koji je
    u odgovarajucem formatu
    
    :param path: putanja do fajla iz kojeg se ucitavaju studenti
    '''
    if path is None:
        raise ValueError("Putanja mora biti string")
    if type(path) is not str:
        raise TypeError("Putanja mora biti vrednost tipa string")
    checkFile(path)
    studenti=[]
    with open(path,'r') as f:
        for line in f:
            if len(line) > 1:
                try:
                    stud = str2student(line)
                    studenti.append(stud)
                except ValueError:
                    pass
    return studenti

def checkFile(path):
    '''
    Proverava da li postoji fajl u fajl sistemu
    
    :param path: putanja do fajla koji se proverava da li postoji
    '''
    if not exists(path):
        open(path, 'w').close()