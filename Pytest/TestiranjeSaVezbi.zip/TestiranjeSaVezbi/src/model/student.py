'''
Modul koji sadrzi klasu za entitet Student

@author: Zeljko Ivkovic
'''

class Student(object):
    '''
    Klasa koja sadrzi atribute za studenta
    '''


    def __init__(self, indeks,ime,prezime,roditelj,datum,jmbg,adresa,telefon,email,godina):
        '''
        Constructor
        
        :param indeks:
        :param ime:
        :param prezime:
        :param roditelj:
        :param datum:
        :param jmbg:
        :param adresa:
        :param telefon:
        :param email:
        :param godina:
        '''
        self.indeks=indeks
        self.ime=ime
        self.prezime=prezime
        self.roditelj=roditelj
        self.datum=datum
        self.jmbg=jmbg
        self.adresa=adresa
        self.telefon=telefon
        self.email=email
        self.godina=godina
    
    def student2str(self):
        '''
        Metoda koja vraca vrednosti postavljene za
        atribute studenta u formatu koji se koristi
        za cuvanje u fajlu
        '''
        return '|'.join([self.indeks, self.ime, self.prezime, 
          self.roditelj, self.datum, self.jmbg, self.adresa, 
          self.telefon, self.email, self.godina])
    
    def advanceStudent(self):
        '''
        Metoda koja povecava godinu studenta
        '''
        self.godina+=1

def str2student(line):
    '''
    Metoda koja za prosledjen string objekat u odgovarajucem formatu
    prepoznaje vrednosti i kreira objekat tipa Student postavljajuci
    vrednosti odgovarajucih atributa
        
    :param line: string koji sadrzi sve vrednosti atributa klase Student razdvojene \
    znakom uspravna crta |
    '''
    if line[-1] == '\n':
        line = line[:-1]
    try:
        indeks, ime, prezime, roditelj, datum, jmbg, adresa, telefon, email, godina = line.split('|')
        return Student(indeks, ime, prezime, roditelj, datum, jmbg, adresa, telefon, email, godina)
    except ValueError:
        raise ValueError("String koji ste prosledili ne odgovara formatu za studenta")