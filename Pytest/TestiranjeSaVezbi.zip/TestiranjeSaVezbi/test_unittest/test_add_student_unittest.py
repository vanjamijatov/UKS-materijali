'''
Created on Jun 4, 2018

@author: vezbe
'''
import unittest
from app import vrednosti
from ucitati.studente import ucitatiStudente
from globalne_var_unittest import studentiFajl, studentiPrazanFajl
from model.student import Student
from app.vrednosti import addStudent


class TestAddStudent(unittest.TestCase):


    def setUp(self):
        vrednosti.studenti=ucitatiStudente(studentiFajl)


    def tearDown(self):
        pass


    def test_add_student_uspesno(self):
        student=Student("E7","Kosta","Kostic","Petar","7.8.1951.","0708195180032","Bulevar Oslobodjenja 25, Beograd","011/1234-567","milojko@pantic.com","3")
        addStudent(student)
        self.assertIsNotNone(vrednosti.studenti, "Vrednost vrednosti.studenti mora biti objekat koji je lista")
        self.assertIsInstance(vrednosti.studenti, list, "Vrednosti vrednosti.studenti mora biti lista")
        self.assertEqual(len(vrednosti.studenti), 5, "Lista mora imati 5 elementa")
        self.assertIsInstance(vrednosti.studenti[4], Student, "Poslednji element, koji je ubacen, mora biti tipa Student")
        self.assertEqual(vrednosti.studenti[4].indeks, "E7", "Poslednji element, koji je ubacen, mora imati indeks E7")
    
    def test_add_student_none(self):
        with self.assertRaises(ValueError):
            addStudent(None) 
        
    def test_add_student_int(self):
        with self.assertRaises(TypeError):
            addStudent(1) 

class TestAddStudentPrazanFajl(unittest.TestCase):


    def setUp(self):
        vrednosti.studenti=ucitatiStudente(studentiPrazanFajl)


    def tearDown(self):
        pass
    
    def test_add_student_prazan_fajl(self):
        student=Student("E7","Kosta","Kostic","Petar","7.8.1951.","0708195180032","Bulevar Oslobodjenja 25, Beograd","011/1234-567","milojko@pantic.com","3")
        addStudent(student)
        self.assertIsNotNone(vrednosti.studenti, "Vrednost vrednosti.studenti mora biti objekat koji je lista")
        self.assertIsInstance(vrednosti.studenti, list, "Vrednosti vrednosti.studenti mora biti lista")
        self.assertEqual(len(vrednosti.studenti), 1, "Lista mora imati 1 element")
        self.assertIsInstance(vrednosti.studenti[0], Student, "Jedini element, koji je ubacen, mora biti tipa Student")
        self.assertEqual(vrednosti.studenti[0].indeks, "E7", "Jedini element, koji je ubacen, mora imati indeks E7")
    
    
if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()