
import unittest
from app import vrednosti
from ucitati.studente import ucitatiStudente
from globalne_var_unittest import studentiFajl, studentiPrazanFajl
from app.vrednosti import searchStudentsByName
from model.student import Student


class TestSearch(unittest.TestCase):


    def setUp(self):
        vrednosti.studenti=ucitatiStudente(studentiFajl)


    def tearDown(self):
        pass


    def test_search_vrednost_prezime(self):
        studenti=searchStudentsByName("Pantic")
        self.assertIsNotNone(studenti, "Vrednost studenti mora biti objekat koji je lista")
        self.assertIsInstance(studenti, list, "Vrednosti studenti mora biti lista")
        self.assertEqual(len(studenti), 0, "Lista mora biti prana jer nije pronadjen nijedan student")

    
    def test_search_vise_vrednosti(self):
        studenti=searchStudentsByName("ko")
        self.assertIsNotNone(studenti, "Vrednost studenti mora biti objekat koji je lista")
        self.assertIsInstance(studenti, list, "Vrednosti studenti mora biti lista")
        self.assertEqual(len(studenti), 3, "Lista mora imati 3 elementa")
        self.assertIsInstance(studenti[0], Student, "Pronadjeni objekti moraju biti tipa Student")
        self.assertEqual(studenti[0].ime, "Milojko", "Prvi pronadjen element mora imati u imenu tekst ko")
    
    def test_search_jedna_vrednost(self):
        studenti=searchStudentsByName("Dusko")
        self.assertIsNotNone(studenti, "Vrednost studenti mora biti objekat koji je lista")
        self.assertIsInstance(studenti, list, "Vrednosti studenti mora biti lista")
        self.assertEqual(len(studenti), 1, "Lista mora imati 1 element")
        self.assertIsInstance(studenti[0], Student, "Pronadjeni objekat mora biti tipa Student")
        self.assertEqual(studenti[0].ime, "Dusko", "Pronadjen element mora imati ime Dusko")
    
    def test_search_pogresno_ime(self):
        studenti=searchStudentsByName("Duskoo")
        self.assertIsNotNone(studenti, "Vrednost studenti mora biti objekat koji je lista")
        self.assertIsInstance(studenti, list, "Vrednosti studenti mora biti lista")
        self.assertEqual(len(studenti), 0, "Lista treba da bude prazna, jer nema studenata sa imenom Duskoo")

    def test_search_obrnut_case(self):
        studenti=searchStudentsByName("dU")
        self.assertIsNotNone(studenti, "Vrednost studenti mora biti objekat koji je lista")
        self.assertIsInstance(studenti, list, "Vrednosti studenti mora biti lista")
        self.assertEqual(len(studenti), 1, "Lista mora imati 1 element")
        self.assertIsInstance(studenti[0], Student, "Pronadjeni objekat mora biti tipa Student")
        self.assertEqual(studenti[0].ime, "Dusko", "Pronadjen element mora imati ime Dusko")

    
    def test_search_none(self):
        with self.assertRaises(ValueError):
            searchStudentsByName(None)
    
    def test_search_int(self):
        with self.assertRaises(TypeError):
            searchStudentsByName(1)


class TestSearchPrazanFajl(unittest.TestCase):


    def setUp(self):
        vrednosti.studenti=ucitatiStudente(studentiPrazanFajl)


    def tearDown(self):
        pass
    
    def test_search_prazan_fajl(self):
        studenti=searchStudentsByName("Dusko")
        self.assertIsNotNone(studenti, "Vrednost studenti mora biti objekat koji je lista")
        self.assertIsInstance(studenti, list, "Vrednosti studenti mora biti lista")
        self.assertEqual(len(studenti), 0, "Nema ucitanih studenata i ne moze biti pronadjen nijedan student")

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()