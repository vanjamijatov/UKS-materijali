'''
Created on Jun 4, 2018

@author: vezbe
'''
import unittest
from app import vrednosti
from ucitati.studente import ucitatiStudente
from globalne_var_unittest import studentiFajl, studentiPrazanFajl
from model.student import Student
from app.vrednosti import updateStudent


class TestUpdateStudent(unittest.TestCase):


    def setUp(self):
        vrednosti.studenti=ucitatiStudente(studentiFajl)


    def tearDown(self):
        pass


    def test_update_uspesno(self):
        student=Student("E7","Kosta","Kostic","Petar","7.8.1951.","0708195180032","Bulevar Oslobodjenja 25, Beograd","011/1234-567","milojko@pantic.com","3")
        updateStudent(1,student)
        self.assertIsNotNone(vrednosti.studenti, "Vrednost vrednosti.studenti mora biti objekat koji je lista")
        self.assertIsInstance(vrednosti.studenti, list, "Vrednosti vrednosti.studenti mora biti lista")
        self.assertEqual(len(vrednosti.studenti), 4, "Lista mora imati 4 elementa")
        self.assertIsInstance(vrednosti.studenti[1], Student, "Element koji je izmenjen mora biti tipa Student")
        self.assertEqual(vrednosti.studenti[1].indeks, "E7", "Element koji je izmenjen mora imati indeks E7")

    def test_update_pogresan_index(self):
        student=Student("E7","Kosta","Kostic","Petar","7.8.1951.","0708195180032","Bulevar Oslobodjenja 25, Beograd","011/1234-567","milojko@pantic.com","3")
        with self.assertRaises(IndexError):
            updateStudent(5,student)

    def test_update_none(self):
        with self.assertRaises(ValueError):
            updateStudent(1,None)
        
    def test_update_int(self):
        with self.assertRaises(TypeError):
            updateStudent(1,1)

class TestUpdateStudentPrazanFajl(unittest.TestCase):


    def setUp(self):
        vrednosti.studenti=ucitatiStudente(studentiPrazanFajl)


    def tearDown(self):
        pass
    
    def test_update_prazan_fajl(self):
        student=Student("E7","Kosta","Kostic","Petar","7.8.1951.","0708195180032","Bulevar Oslobodjenja 25, Beograd","011/1234-567","milojko@pantic.com","3")
        with self.assertRaises(IndexError):
            updateStudent(0,student)

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()