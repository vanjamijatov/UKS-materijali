'''
Created on Jun 4, 2018

@author: vezbe
'''
import unittest
from ucitati.studente import ucitatiStudente
from globalne_var_unittest import studentiFajl, studentiPrazanFajl
from model.student import Student


class TestUcitavanje(unittest.TestCase):

    def test_ucitati_vise_vrednosti(self):
        studenti=ucitatiStudente(studentiFajl)
        self.assertIsNotNone(studenti, "Vrednost studenti mora biti objekat koji je lista")
        self.assertIsInstance(studenti, list, "Vrednosti studenti mora biti lista")
        self.assertEqual(len(studenti), 4, "Lista mora imati 4 elementa")
        self.assertIsInstance(studenti[0], Student, "Ucitani objekti moraju biti tipa Student")
        self.assertEqual(studenti[0].indeks, "E1", "Prvi ucitani element mora imati indeks E1")


    def test_ucitati_prazan(self):
        studenti=ucitatiStudente(studentiPrazanFajl)
        self.assertIsNotNone(studenti, "Vrednost studenti mora biti objekat koji je lista")
        self.assertIsInstance(studenti, list, "Vrednosti studenti mora biti lista")
        self.assertEqual(len(studenti), 0, "Lista mora biti prazna, jer ucitavamo prazan fajl")
    
    def test_ucitati_none(self):
        with self.assertRaises(ValueError):
            ucitatiStudente(None)
            
    def test_ucitati_int(self):
        with self.assertRaises(TypeError):
            ucitatiStudente(1)


if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()