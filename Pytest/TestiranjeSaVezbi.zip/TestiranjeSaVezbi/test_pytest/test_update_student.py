import pytest
from app import vrednosti
from ucitati.studente import ucitatiStudente
from globalne_var import studentiFajl, studentiPrazanFajl
from app.vrednosti import updateStudent
from model.student import Student

@pytest.fixture(scope="module")
def pripremi_studente():
    vrednosti.studenti=ucitatiStudente(studentiFajl)
    
def test_update_uspesno(pripremi_studente):
    student=Student("E7","Kosta","Kostic","Petar","7.8.1951.","0708195180032","Bulevar Oslobodjenja 25, Beograd","011/1234-567","milojko@pantic.com","3")
    updateStudent(1,student)
    assert vrednosti.studenti is not None
    assert type(vrednosti.studenti) is list
    assert len(vrednosti.studenti) == 4
    assert type(vrednosti.studenti[1]) is Student
    assert vrednosti.studenti[1].indeks == "E7"

def test_update_pogresan_index(pripremi_studente):
    student=Student("E7","Kosta","Kostic","Petar","7.8.1951.","0708195180032","Bulevar Oslobodjenja 25, Beograd","011/1234-567","milojko@pantic.com","3")
    with pytest.raises(IndexError):
        updateStudent(5,student)

def test_update_none(pripremi_studente):
    with pytest.raises(ValueError):
        updateStudent(1,None)
        
def test_update_int(pripremi_studente):
    with pytest.raises(TypeError):
        updateStudent(1,1)
        
@pytest.fixture(scope="module")
def pripremi_studente_prazan_fajl():
    vrednosti.studenti=ucitatiStudente(studentiPrazanFajl)
    
def test_update_prazan_fajl(pripremi_studente_prazan_fajl):
    student=Student("E7","Kosta","Kostic","Petar","7.8.1951.","0708195180032","Bulevar Oslobodjenja 25, Beograd","011/1234-567","milojko@pantic.com","3")
    with pytest.raises(IndexError):
        updateStudent(0,student)