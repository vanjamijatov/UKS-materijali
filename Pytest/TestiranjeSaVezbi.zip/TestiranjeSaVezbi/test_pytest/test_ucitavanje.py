from ucitati.studente import ucitatiStudente
from globalne_var import studentiFajl, studentiPrazanFajl
from model.student import Student
import pytest

def test_ucitati_vise_vrednosti():
    studenti=ucitatiStudente(studentiFajl)
    assert studenti is not None
    assert type(studenti) is list
    assert len(studenti) == 4
    assert type(studenti[0]) is Student
    assert studenti[0].indeks == "E1" 

def test_ucitati_prazan():
    studenti=ucitatiStudente(studentiPrazanFajl)
    assert studenti is not None
    assert type(studenti) is list
    assert len(studenti) == 0
    
def test_ucitati_none():
    with pytest.raises(ValueError):
        ucitatiStudente(None)
def test_ucitati_int():
    with pytest.raises(TypeError):
        ucitatiStudente(1)