'''

@author: Zeljko Ivkovic
'''
import pytest
from app.vrednosti import findStudent
from ucitati.studente import ucitatiStudente
from app import vrednosti
from globalne_var import studentiFajl, studentiPrazanFajl

# module, session, function
@pytest.fixture(scope="module")
def pripremi_studente():
    vrednosti.studenti=ucitatiStudente(studentiFajl)
    
@pytest.fixture(scope="module")
def pripremi_studente_prazan_fajl():
    vrednosti.studenti=ucitatiStudente(studentiPrazanFajl)
    
def test_find_prazana_lista(pripremi_studente_prazan_fajl):
    s=findStudent("E1")
    assert s is None
    
def test_find(pripremi_studente):
    s=findStudent("E1")
    assert s is not None
    assert s.indeks=="E1"

def test_find_none(pripremi_studente):
    with pytest.raises(ValueError):
        findStudent(None)
        
def test_find_int(pripremi_studente):
    with pytest.raises(TypeError):
        findStudent(2)
        
def test_find_nije_pronadjen(pripremi_studente):
    s=findStudent("E5")
    assert s is None