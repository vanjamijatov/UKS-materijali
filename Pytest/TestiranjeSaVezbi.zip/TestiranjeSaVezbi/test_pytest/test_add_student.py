from app.vrednosti import addStudent
from model.student import Student
from ucitati.studente import ucitatiStudente
from globalne_var import studentiFajl, studentiPrazanFajl
from app import vrednosti
import pytest

@pytest.fixture(scope="module")
def pripremi_studente():
    vrednosti.studenti=ucitatiStudente(studentiFajl)
    
def test_add_student_uspesno(pripremi_studente):
    student=Student("E7","Kosta","Kostic","Petar","7.8.1951.","0708195180032","Bulevar Oslobodjenja 25, Beograd","011/1234-567","milojko@pantic.com","3")
    addStudent(student)
    assert vrednosti.studenti is not None
    assert type(vrednosti.studenti) is list
    assert len(vrednosti.studenti) == 5
    assert vrednosti.studenti[4].indeks == "E7"
    
def test_add_student_none(pripremi_studente):
    with pytest.raises(ValueError):
        addStudent(None) 
        
def test_add_student_int(pripremi_studente):
    with pytest.raises(TypeError):
        addStudent(1) 
        
@pytest.fixture(scope="module")
def pripremi_studente_prazan_fajl():
    vrednosti.studenti=ucitatiStudente(studentiPrazanFajl)
    
def test_add_student_prazan_fajl(pripremi_studente_prazan_fajl):
    student=Student("E7","Kosta","Kostic","Petar","7.8.1951.","0708195180032","Bulevar Oslobodjenja 25, Beograd","011/1234-567","milojko@pantic.com","3")
    addStudent(student)
    assert vrednosti.studenti is not None
    assert type(vrednosti.studenti) is list
    assert len(vrednosti.studenti) == 1
    assert vrednosti.studenti[0].indeks == "E7"