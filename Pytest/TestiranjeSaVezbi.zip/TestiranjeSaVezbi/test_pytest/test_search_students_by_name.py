import pytest
from app import vrednosti
from ucitati.studente import ucitatiStudente
from globalne_var import studentiFajl, studentiPrazanFajl
from app.vrednosti import searchStudentsByName
from model.student import Student
from test_vrednosti import pripremi_studente_prazan_fajl

@pytest.fixture(scope="module")
def pripremi_studente():
    vrednosti.studenti=ucitatiStudente(studentiFajl)
    

def test_search_vrednost_prezime(pripremi_studente):
    studenti=searchStudentsByName("Pantic")
    assert studenti is not None
    assert type(studenti) is list
    assert len(studenti) == 0
    
def test_search_vise_vrednosti(pripremi_studente):
    studenti=searchStudentsByName("ko")
    assert studenti is not None
    assert type(studenti) is list
    assert len(studenti) == 3
    assert type(studenti[0]) is Student
    assert studenti[0].ime == "Milojko"
    
def test_search_jedna_vrednost(pripremi_studente):
    studenti=searchStudentsByName("Dusko")
    assert studenti is not None
    assert type(studenti) is list
    assert len(studenti) == 1
    assert type(studenti[0]) is Student
    assert studenti[0].ime == "Dusko"
    
def test_search_pogresno_ime(pripremi_studente):
    studenti=searchStudentsByName("Duskoo")
    assert studenti is not None
    assert type(studenti) is list
    assert len(studenti) == 0

def test_search_obrnut_case(pripremi_studente):
    studenti=searchStudentsByName("dU")
    assert studenti is not None
    assert type(studenti) is list
    assert len(studenti) == 1
    assert type(studenti[0]) is Student
    assert studenti[0].ime == "Dusko"
    
def test_search_none(pripremi_studente):
    with pytest.raises(ValueError):
        searchStudentsByName(None)
    
def test_search_int(pripremi_studente):
    with pytest.raises(TypeError):
        searchStudentsByName(1)
        
@pytest.fixture(scope="module")
def pripremi_studente_prazan_fajl():
    vrednosti.studenti=ucitatiStudente(studentiPrazanFajl)
    
def test_search_prazan_fajl(pripremi_studente_prazan_fajl):
    studenti=searchStudentsByName("Dusko")
    assert studenti is not None
    assert type(studenti) is list
    assert len(studenti) == 0