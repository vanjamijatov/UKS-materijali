'''

@author: Zeljko
'''
import os

studentiFajl=os.path.join(os.path.dirname(__file__), '..','podaci_testiranje','studenti.txt')