'''

@author: Zeljko Ivkovic
'''
import pytest
from app.vrednosti import findStudent
from ucitati.studente import ucitatiStudente
from app import vrednosti
from globalne_var import studentiFajl

# module, session, function
@pytest.fixture(scope="module")
def pripremi_studente():
    vrednosti.studenti=ucitatiStudente(studentiFajl)
    
def test_find(pripremi_studente):
    s=findStudent("E1")
    assert s!=None
    assert s.indeks=="E1"

def test_find_none(pripremi_studente):
    with pytest.raises(ValueError):
        findStudent(None)