'''
Modul u kojem se nalaze globalna promenljiva studenti koja cuva
listu studenata i funkcije koje rade sa tom globalnom promenljivom

@author: Zeljko Ivkovic
'''

studenti=[]

def findStudent(indeks):
    '''
    Pronalazi studenta sa prosledjenim indeksom
    
    :param indeks: broj indeksa studenta
    '''
    if indeks is None:
        raise ValueError("Parametar indeks ne moze biti nedefinisan")
    for stud in studenti:
        if stud.indeks == indeks:
            return stud
    return None
    
def searchStudentsByName(value):
    '''
    Metoda pronalazi sve studente koji u imenu sadrze prosledjen
    string objekat.
     
    :param value: tekst koji treba da se poklopi sa imenom studenta
    '''
    if(value is None):
        raise ValueError("Parametar value ne moze biti nedefinisan")
    result = [] 
    for stud in studenti:
        if value.upper() in stud.ime.upper() :
            result.append(stud)
    return result

def addStudent(stud):
    '''
    Metoda koja dodaje novog studenta u listu studenata.
    
    :param stud: objekat tipa Student
    '''
    if(stud is None):
        raise ValueError("Parametar stud ne moze biti nedefinisan")
    studenti.append(stud)

def updateStudent(index, stud):
    '''
    Promena vrednosti studenta na odgovarajucoj poziciji u listi studenata
    
    :param index: pozicija u listi studenata
    :param stud: objekat tipa student 
    '''
    if(stud is None):
        raise ValueError("Parametar stud ne moze biti nedefinisan")
    if len(studenti)<=index:
        raise IndexError("Parametar index sadrzi vecu vrednost nego sto ima elemenata u listi studenata")
    studenti[index] = stud