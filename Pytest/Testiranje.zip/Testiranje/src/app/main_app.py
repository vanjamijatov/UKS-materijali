'''
Glavni modul, koji sluzi za pokretanje programa.

@author: Zeljko Ivkovic

'''
from app.vrednosti import findStudent
from ucitati.studente import ucitatiStudente
from app import vrednosti
import os

studentiFajl=os.path.join(os.path.dirname(__file__),"..","..","podaci","studenti.txt")

if __name__ == '__main__':
    vrednosti.studenti=ucitatiStudente(studentiFajl)
    student=findStudent("E1")
    print(student.student2str())
    