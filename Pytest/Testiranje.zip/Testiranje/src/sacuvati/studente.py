'''
Modul koji sadrzi funkciju za upis objekata tipa Student u fajl

@author: Zeljko Ivkovic
'''

def sacuvatiStudente(path,studenti):
    '''
    Metoda koja upisuje sve studente u fajl u unpared
       predvidjenom formatu
       
    :param path: putanja do fajla u koji se upisuju studenti
    :param studenti: lista studenata za upis u fajl
    '''
    textFile = open(path, 'w')
    for stud in studenti:
        textFile.write(stud.student2str())
        textFile.write('\n')
    textFile.close()