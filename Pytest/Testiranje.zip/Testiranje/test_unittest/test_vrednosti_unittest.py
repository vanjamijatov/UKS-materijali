'''

@author: Zeljko Ivkovic
'''
from app.vrednosti import findStudent
from ucitati.studente import ucitatiStudente
from globalne_var_unittest import studentiFajl
from app import vrednosti
import unittest


class TestVrednosti(unittest.TestCase):
    def setUp(self):
        '''
        Pre pocetka testiranja postavljamo pocetne vrednosti
        '''
        vrednosti.studenti=ucitatiStudente(studentiFajl)
    
    def test_find(self):
        s=findStudent("E1")
        self.assertIsNotNone(s,"Vrednost studenta mora biti vracena")
        self.assertEqual(s.indeks,"E1","Nije pronadjen student sa brojem indeksa E1")

    def test_find_none(self):
        with self.assertRaises(ValueError):
            findStudent(None)
            
            
    def tearDown(self):
        '''
        Kada zarvrsimo sa testom oslobadjanje resursa
        '''
        pass
    
    
    