from django.apps import AppConfig


class ProdavniceConfig(AppConfig):
    name = 'prodavnice'
    verbose_name = 'Evidencija prodavnica'
